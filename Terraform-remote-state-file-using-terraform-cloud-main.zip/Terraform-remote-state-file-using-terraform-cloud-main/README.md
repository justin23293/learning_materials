# Manage Terraform remote state file using terraform cloud
 
This project involved the management of terraform remote state file in the terraform cloud and demostration of how to create Terraform cloud account and workspaces to manage remote state file.

For step by step implementation follow this [article](https://palak-bhawsar.hashnode.dev/easily-manage-your-terraform-remote-state-file-with-terraform-cloud).

![Yellow Bright Business Idea Tutorial Youtube Thumbnail (1)](https://github.com/palakbhawsar98/Terraform-remote-state-file-using-terraform-cloud/assets/69889600/c80be385-3050-4dff-bda0-7ce24d9f2d0d)
