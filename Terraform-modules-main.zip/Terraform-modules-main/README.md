## Terraform modules
- **IAM**
#### Usecase: Create an IAM user and attach IAM policy to access particular S3 bucket
